# XDG portals: screen sharing, screenshots, file pickers.
# Replaces the Fedora-only /usr/libexec portal lines in autostart.sh.
{ pkgs, ... }:
{
  xdg.portal = {
    enable = true;
    wlr.enable = true;                       # screen capture on wlroots compositors
    extraPortals = [ pkgs.xdg-desktop-portal-gtk ];
    config = {
      common.default = [ "gtk" ];
      # Name matches XDG_CURRENT_DESKTOP=mango from your env.conf
      mango.default = [ "wlr" "gtk" ];
    };
  };
}
